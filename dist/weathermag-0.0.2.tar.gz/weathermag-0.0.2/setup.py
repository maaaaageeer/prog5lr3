import setuptools

with open("README.md",'r',encoding='utf-8') as fh:
    desc = fh.read()

setuptools.setup(
    #name = "WeatherMag",
 #                version= "0.0.1",
 #                author= "Maaaggerr",
 #                package_dir = {"":"src"},
 #                long_description=desc,
 #                packages=setuptools.find_packages(where='src'),
 #                requires= ">=3.6",
#                 classifiers= [
#                     "Programming Language :: Python :: 3",
#                     "Operating System :: OS Independent",
#                 ]
                 )
