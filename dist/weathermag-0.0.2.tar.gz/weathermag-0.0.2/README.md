# 'WeatherMag'
The 'WeatherMag' is app to ckeck weather in cities.